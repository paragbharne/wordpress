<div style="text-align: center; font-weight: bold; margin-top: 50px">
	Thank you for filling out the form
</div>
<iframe src="<?php echo esc_attr( $postprocess_url ) ?>" width="0" height="0"></iframe>
