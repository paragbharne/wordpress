<?php

ITSEC_Modules::register_module( 'security-check', dirname( __FILE__ ), 'always-active' );
