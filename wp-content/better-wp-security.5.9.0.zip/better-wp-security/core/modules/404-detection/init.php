<?php

ITSEC_Modules::register_module( '404-detection', dirname( __FILE__ ) );
