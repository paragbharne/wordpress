<?php

ITSEC_Modules::register_module( 'file-writing', dirname( __FILE__ ), 'always-active' );
