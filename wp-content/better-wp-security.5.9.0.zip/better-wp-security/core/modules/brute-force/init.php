<?php

ITSEC_Modules::register_module( 'brute-force', dirname( __FILE__ ), 'default-active' );
